<fieldset>
    <legend><b>PROFILE PICTURE</b></legend>
    <form method="post" action="piccheck.php" enctype="multipart/form-data">
        <img width="128" src="pics/<?=$_COOKIE["name"]?>" />
        <br />
        <input type="file" name="propic">
        <hr />
        <input type="submit" value="Submit" name="submit">
    </form>
</fieldset>