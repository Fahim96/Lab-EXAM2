<?php
//echo $_POST['npass'];
//echo $_POST['cpass'];
//echo $_POST['rpass'];
$uname=$_COOKIE['name'];

error_reporting(0);
	if($_POST['npass'] != $_POST['cpass'] && !empty($_POST['npass']) && $_POST['cpass'] == $_COOKIE['password'])
	{
		if($_POST['rpass'] == $_POST['npass'] && !empty($_POST['rpass'] ))
		{ 
	         $npass=$_POST['npass'];
			$servername ="localhost";
			$username 	="root";
			$password 	="";
			$dbname 	="lab7";
			
			
			$conn = mysqli_connect($servername, $username, $assword, $dbname);
			
			if(!$conn){
				die("Connection Error!".mysqli_connect_error());
			}
			$sql = "UPDATE user SET password='$npass' WHERE UserName='$uname' ";
			$result=mysqli_query($conn,$sql);
			if($result)
			{
				setcookie("password",$npass,time()+(86400 *30), "/");
				echo "password updated";
			}
			else
			{
				echo "something wrong";
			}
			
			
			
		}
				else
						echo "retype password should be matched";
	}
	else
	{echo "please enter a new password or check the current password again" ;}
?>

<fieldset>
    <legend><b>CHANGE PASSWORD</b></legend>
    <form method="post" action="#">
        <table>
            <tr>
                <td><font size="3">Current Password</font></td>
				<td>:</td>
                <td><input type="password" name="cpass" /></td>
                <td></td>
            </tr>
            <tr>
                <td><font size="3" color="green">New Password</font></td>
				<td>:</td>
                <td><input type="password" name="npass" /></td>
                <td></td>
            </tr>
            <tr>
                <td><font size="3" color="red">Retype New Password</font></td>
				<td>:</td>
                <td><input type="password" name="rpass"/></td>
                <td></td>
            </tr>
        </table>
        <hr />
        <input type="submit" value="Submit" name="submit" />
    </form>
</fieldset>