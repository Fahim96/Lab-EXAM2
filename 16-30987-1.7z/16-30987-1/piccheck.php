<?php
error_reporting(0);
$filename=$_COOKIE['name'];
$fileuploadpath="pics/".$filename;
if(file_exists($fileuploadpath))
{
	unlink($fileuploadpath);
}
if(move_uploaded_file($_FILES['propic']['tmp_name'],$fileuploadpath))
{
	echo "profile picture changed"; ?>
	<a href="profile.php">Visit profile</a>
	<?php
}
else
	echo "something went wrong . try again";
?>