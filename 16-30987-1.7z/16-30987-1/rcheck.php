<?php
    error_reporting(0);
	$servername ="localhost";
	$username 	="root";
	$password 	="";
	$dbname 	="lab7";
	$name=$_POST['name'];
	$email=$_POST['email'];
	$fusername=$_POST['username'];
	$fpassword=$_POST['password'];
	$gender=$_POST['gender'];
	$datee=$_POST['date'];
	$month=$_POST['month'];
	$year=$_POST['year'];
	$dob= $datee."-".$month."-".$year;
	if(empty($name) ||empty($email) ||empty($fusername) ||empty($fpassword) ||empty($gender) ||empty($datee) ||empty($month) ||empty($year)   )
				{die("Please fill up all the fields\r\n");}
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}
	
	$sql = "insert into user values('$name','$email','$fusername','$fpassword','$gender','$dob')";
	
	if(mysqli_query($conn, $sql)){
		echo "<br/> Data Inserted!";
	}else{
		echo "<br/> SQL Error".mysqli_error($conn);
	}

	mysqli_close($conn);
?>