<?php
setcookie("name", $fusername , time()-(86400 *30), "/");
setcookie("email",$email,time()-(86400 *30), "/");
setcookie("gender",$gender,time()-(86400 *30), "/");
setcookie("dob",$gender,time()-(86400 *30), "/");
setcookie("password",$gender,time()-(86400 *30), "/");
header("Location:login.html");

?>