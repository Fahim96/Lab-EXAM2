<?php
    
	$servername ="localhost";
	$username 	="root";
	$password 	="";
	$dbname 	="lab7";
	$fusername = $_POST['fusername'];
	$fpassword = $_POST['fpassword'];
	
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}
	
	$sql = "select * from user WHERE UserName='$fusername' AND password='$fpassword' ";
	$result = mysqli_query($conn, $sql);
	
	if(mysqli_num_rows($result)>0){
		
	    setcookie("name", $fusername , time()+(86400 *30), "/");
		while($row=mysqli_fetch_assoc($result))
	{
		$email=$row['Email'];
		setcookie("email",$email,time()+(86400 *30), "/");
		$gender=$row['Gender'];
		setcookie("gender",$gender,time()+(86400 *30), "/");
		$gender=$row['Dob'];
		setcookie("dob",$gender,time()+(86400 *30), "/");
		$password=$row['Password'];
		setcookie("password",$fpassword,time()+(86400 *30), "/");


	}
		header("Location:loggedin_layout.php");
		
	   }
		
	else{
		header("Location:login.html");
	}

	mysqli_close($conn);
?>